import React from "react";

const temp = () => {
  return (
    <div className="toughts-page w-full min-h-screen bg-gray-50">
      <Navbar />
      <main className="container w-full mx-0 px-4 pt-34 pb-16 sm:pt-40 md:pt-36 max-w-[1350px]">
        <div className="flex flex-col gap-8 mx-[8%]">
          <div className=" w-[902px]"></div>
        </div>
      </main>
    </div>
  );
};

export default temp;
